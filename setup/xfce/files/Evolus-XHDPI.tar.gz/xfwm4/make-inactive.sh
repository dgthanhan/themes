#!/bin/sh

indexes=(2 3 4 5)
for index in "${indexes[@]}"
do 
  cp -f title-1-active.png title-$index-active.png
done

cp -f top-left-active.png top-right-active.png

for name in *-active.png
do 
  new_name=`echo $name | sed -e s/active/inactive/g`
  convert -brightness-contrast 20x0 $name $new_name
  echo $new_name 
done

names=("bottom" "bottom-left" "bottom-right" "right")

cp -f left-active.png bottom-active.png
for n in "${names[@]}"
do 
  cp -f left-active.png $n-active.png
  cp -f left-active.png $n-inactive.png
done

cp -f left-active.png left-inactive.png
  
  
